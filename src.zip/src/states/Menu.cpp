#include "game/Game.h"
#include "HelperFuncs.h"

void UpdateMenu(Game &game)
{
    return;
}

void DrawMenu(const Game &game)
{
    DrawCenteredTitleX("MENU", 20, 10, WHITE);
}